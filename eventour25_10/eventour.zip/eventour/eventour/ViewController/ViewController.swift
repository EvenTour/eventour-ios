//
//  ViewController.swift
//  eventour
//
//  Created by Rafael on 10/24/18.
//  Copyright © 2018 Rafael. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

