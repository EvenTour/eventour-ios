//
//  EventViewController.swift
//  eventour
//
//  Created by Alumnos on 10/25/18.
//  Copyright © 2018 Rafael. All rights reserved.
//


import UIKit

import os


class EventViewController: UIViewController {
    
    @IBOutlet weak var sampleImageView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let sample = "http://www.fuenteagria.net/theme/Fuenteagria/css/web/noevento.png"
        
        sampleImageView.setImageFrom(
            urlString: sample,
            withDefaultNamed: "no-image",
            withErrorNamed: "no-image")
        
    }
    
    
}
